<?php
$conn = new mysqli ("db", "user", "pass", "ctf_db");

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['username']) && isset($_POST['password'])){
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";

	$result = $conn->query($sql);

	if ($result && $result->num_rows > 0) {
		$flagResult = $conn->query("SELECT flag FROM flags LIMIT 1");
		$flagRow = $flagResult->fetch_assoc();
		echo "<h1>Welcome, $username!</h1>";
		echo "<p>FLAG: " . $flagRow['flag'] . "</p>";
	} else {
		echo "<p>Invalid login.</p>";
	}
}
?>

<form method="POST">
	Username: <input name="username"><br>
	Password: <input name="password"><br>
	<input type="submit" value="Login">
</form>
