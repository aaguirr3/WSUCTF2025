# SQL Injection Challenge - CTF Edition 
Welcome to  Wayne State Cyber Defense Club's CTF - SQL Injection Challenge 
Difficulty: Easy/Medium

Objective: Bypass the login form and retrieve the hidden flag using SQL injection
Description: A simple login portal has been set up for internal users, can you find a way to bypass it? 
Flag format: 'flag{...}'

#Requirements:
- [Docker](https://www.docker.com/) and [Docker Compose] (https://docs.docker.com/compose/) installed on your machine

#Running the Challenge Locally 
1. Open the terminal in this directory (sqli-ctf-site/)
2. Run the following command:
 > docker-compose up --build
3. Once the containers are running, go into your browser of choice and visit:
http://localhost:8080

#Objective:
Use SQL injection to log in without the valid credentials and retrieve the flag.

#Tips
Username and password fields are not sanitized
Try some simple payloads ;) 
No need for brute force or fancy tools
This is a safe, isolated environment. Have fun testing! 
